{
    events: [
        {
            timestamp: 1558017455,
            type: "openModal", // programChange, changeRecord, runQuery
            details: {
                modal: "modalID",
            },
            currentProgram: "INVPEN",
        },
        {
            timestamp: 1558017455,
            type: "programChange",
            details: {
                program: "XXXXXX",
            },
            currentProgram: "INVPEN",
        },
        {
            timestamp: 1558017455,
            type: "runQuery",
            details: {
                query: "XXXXXX",
            },
            currentProgram: "INVPEN",
        },
    ];
}
